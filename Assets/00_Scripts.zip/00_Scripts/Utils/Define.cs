using UnityEngine;

public class Define
{
    public enum Scene
    {
        Unknown,
        Lobby,
        Game,
    }

    public enum UIEvent
    {
        Click,
    }
}
